Wichtig: Der AT-Patcher deaktiviert nur die Telemetrie
	 durch das �ndern bestimmter Registrywerte. 
	 Andere "Spionage-Funktionen" von Microsoft bleiben
	 jedoch weiterhin aktiv.